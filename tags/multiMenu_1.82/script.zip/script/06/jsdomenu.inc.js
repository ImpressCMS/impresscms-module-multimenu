function createjsDOMenuc() {
	
}